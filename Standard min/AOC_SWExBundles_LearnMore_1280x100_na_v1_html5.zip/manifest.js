FT.manifest({
	"filename":"index.html",
	"width":1280,
	"height":100,
	"clickTagCount":1
});