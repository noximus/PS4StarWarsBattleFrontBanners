FT.manifest({
	"filename":"index.html",
	"width":600,
	"height":400,
	"clickTagCount":1
});