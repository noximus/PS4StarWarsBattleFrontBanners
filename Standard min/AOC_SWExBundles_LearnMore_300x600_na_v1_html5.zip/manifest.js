FT.manifest({
	"filename":"index.html",
	"width":300,
	"height":600,
	"clickTagCount":1
});