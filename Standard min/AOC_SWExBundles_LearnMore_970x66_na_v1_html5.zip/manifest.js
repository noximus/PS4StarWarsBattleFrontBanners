FT.manifest({
	"filename":"index.html",
	"width":970,
	"height":66,
	"clickTagCount":1
});