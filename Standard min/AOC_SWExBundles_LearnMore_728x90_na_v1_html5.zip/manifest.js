FT.manifest({
	"filename":"index.html",
	"width":728,
	"height":90,
	"clickTagCount":1
});