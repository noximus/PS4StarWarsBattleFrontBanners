FT.manifest({
	"filename":"index.html",
	"width":1280,
	"height":100,
  "clickTagCount":1,
  "expand":{
    "fullscreen":false,
    "width":1280,
    "height":418,
    "indentAcross":0,
    "indentDown":0
  },
  "hideBrowsers": ["ie8"],
  "videos": [{"name": "video1", "ref": "https://youtu.be/RdUak_vvNsk"}],
  "instantAds":[
  {"name":"video1", "type":"text", "default":"https://youtu.be/RdUak_vvNsk"}]
});
